# CS180-Project
This is a Machine Learning Project to determine the Housing and Water Expenditure Base on Household-Level Data from the FIES Dataset of Kaggle. The project aims to develop a regression model that can predict housing and water expenditure based on user information. The group's objective is to assist Filipino households in their financial management and provide future household heads with estimates of costs related to housing, water, and electricity, thereby aiding them in their family or house plans.

This is the group's web application that facilitate user interaction.

Team Members:

Cagulada, Roel Francos - WFX <br />
Camingao, Ethan Joshua - WFY <br />
Logroño, Brylle Joshua - WFY <br />
Villos, Raymart Andrew - WFY <br />
